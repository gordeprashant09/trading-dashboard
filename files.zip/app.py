"""
app.py — Unified Trading Dashboard
====================================
Single Streamlit entry point that merges:
  1. 📊 Position Book  (trading_dashboard_colo_prod_final.py)
  2. 📈 Charts         (dashboard_charts.py)
  3. 📅 Daily PnL      (dropcopy_pnl_tab.py)

Run:
    streamlit run app.py --server.port 8502

Keep these files in the SAME folder:
    app.py
    trading_dashboard_colo_prod_final.py
    dashboard_charts.py
    dropcopy_pnl_tab.py
    dashboard_worker_prod.py        (used internally by trading_dashboard)
    dashboard_chart_collector.py    (cron job — run separately, NOT by this app)
    dropcopy_summary_writer.py      (cron job — run separately at 15:31)

Changes vs v1:
    - use_container_width deprecated warning fixed (width="stretch" in charts/dropcopy files)
    - Modules are always force-reloaded so updated logic is picked up on restart
"""

from __future__ import annotations

import importlib.util
import sys
import os
import streamlit as st
from streamlit_autorefresh import st_autorefresh
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

# ─────────────────────────────────────────────────────────────────
# PAGE CONFIG  — must be the very first Streamlit call
# ─────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Trading Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─────────────────────────────────────────────────────────────────
# SHARED CSS
# ─────────────────────────────────────────────────────────────────
st.html("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap');

#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 0.6rem !important; padding-bottom: 0.5rem !important; }

[data-testid="stMetricValue"] {
    font-size: 1.3rem !important; font-weight: 600;
    font-family: 'JetBrains Mono', monospace !important;
}
[data-testid="stMetricLabel"] {
    font-size: 10px !important; text-transform: uppercase;
    letter-spacing: .08em; color: #555c6e !important;
}
[data-testid="stMetric"] {
    background: #13151a;
    border: 1px solid #1e2230;
    border-radius: 6px;
    padding: 10px 14px !important;
}

/* tab strip styling */
[data-testid="stTabs"] [data-baseweb="tab-list"] {
    gap: 4px;
    border-bottom: 1px solid #1e2230 !important;
    padding-bottom: 0;
}
[data-testid="stTabs"] [data-baseweb="tab"] {
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 12px; font-weight: 600;
    color: #555c6e;
    padding: 6px 16px;
    border-radius: 4px 4px 0 0;
    background: transparent;
}
[data-testid="stTabs"] [aria-selected="true"] {
    color: #c8cdd8 !important;
    border-bottom: 2px solid #2eca8a !important;
    background: #13151a !important;
}
</style>
""")

# ─────────────────────────────────────────────────────────────────
# TOP HEADER BAR
# ─────────────────────────────────────────────────────────────────
col_logo, col_clock = st.columns([6, 1])
with col_logo:
    st.html(
        "<div style='font-family:IBM Plex Sans,sans-serif;"
        "font-size:18px;font-weight:600;color:#c8cdd8;"
        "letter-spacing:.02em;padding-top:4px'>"
        "📊 Prod Trading Dashboard</div>"
    )
with col_clock:
    st.html(
        f"<div style='text-align:right;font-size:11px;"
        f"font-family:JetBrains Mono;color:#555c6e;padding-top:6px'>"
        f"{datetime.now(IST).strftime('%d %b %Y')}<br>"
        f"<span style='color:#c8cdd8'>{datetime.now(IST).strftime('%H:%M:%S')}</span>"
        f"</div>"
    )

st.html("<div style='margin:4px 0 8px'></div>")

# ─────────────────────────────────────────────────────────────────
# THREE TABS
# ─────────────────────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs([
    "📊  Position Book",
    "📈  MTM vs NIFTY",
    "📅  Daily PnL (Dropcopy)",
])


# ══════════════════════════════════════════════════════════════════
# MODULE LOADER HELPER
# Suppresses each module's own st.set_page_config() and the first
# top-level st.html() CSS block so they don't conflict with app.py.
# Always force-reloads so updated logic is picked up on restart.
# ══════════════════════════════════════════════════════════════════

def _load_module(mod_name: str):
    """
    Load a sibling .py file as a module, neutralising its top-level
    st.set_page_config() and first st.html() CSS call.
    Force-reloads every time so file edits are always reflected.
    """
    _orig_set_page_config = st.set_page_config
    _orig_html            = st.html

    noop = lambda *a, **kw: None
    st.set_page_config = noop

    # Suppress only the FIRST st.html call at module level (the CSS block).
    # All subsequent st.html calls inside functions are passed through normally.
    _count = {"n": 0}
    def _guarded_html(*a, **kw):
        _count["n"] += 1
        if _count["n"] == 1:
            return None
        return _orig_html(*a, **kw)
    st.html = _guarded_html

    try:
        # Always force-reload so updated file logic is picked up
        if mod_name in sys.modules:
            del sys.modules[mod_name]

        spec = importlib.util.spec_from_file_location(
            mod_name,
            os.path.join(os.path.dirname(os.path.abspath(__file__)), f"{mod_name}.py"),
        )
        mod = importlib.util.module_from_spec(spec)
        sys.modules[mod_name] = mod
        spec.loader.exec_module(mod)
    finally:
        st.set_page_config = _orig_set_page_config
        st.html            = _orig_html

    return mod


# ── Tab 1 — Position Book ─────────────────────────────────────────
with tab1:
    try:
        pb_mod = _load_module("trading_dashboard_colo_prod_final")
        pb_mod.main()
    except Exception as e:
        st.error(f"Position Book failed to load: {e}")
        st.exception(e)


# ── Tab 2 — MTM vs NIFTY Charts ───────────────────────────────────
with tab2:
    try:
        ch_mod = _load_module("dashboard_charts")

        # dashboard_charts.main() contains two inner tabs:
        #   - MTM vs NIFTY  (what we want here)
        #   - Daily PnL     (shown in Tab 3 instead)
        # Patch the dropcopy function to a redirect message so it
        # doesn't render twice.
        from dropcopy_pnl_tab import show_dropcopy_pnl_tab as _real_dct
        ch_mod.show_dropcopy_pnl_tab = lambda: st.info(
            "📅 Daily PnL is available in the **Daily PnL (Dropcopy)** tab →"
        )
        ch_mod.main()
        ch_mod.show_dropcopy_pnl_tab = _real_dct  # restore

    except Exception as e:
        st.error(f"Charts failed to load: {e}")
        st.exception(e)


# ── Tab 3 — Daily PnL Dropcopy ────────────────────────────────────
with tab3:
    try:
        from dropcopy_pnl_tab import show_dropcopy_pnl_tab
        show_dropcopy_pnl_tab()
    except Exception as e:
        st.error(f"Daily PnL tab failed to load: {e}")
        st.exception(e)
